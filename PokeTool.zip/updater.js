const APP_DIR = "PokeTool";
const VERSION_URL = "https://raw.githubusercontent.com/tuando-hub/Poke-Tool/main/release/app.json";
const ZIP_URL = "https://raw.githubusercontent.com/tuando-hub/Poke-Tool/main/release/PokeTool.zip";

async function getRemoteVersion() {
  const resp = await $http.get(VERSION_URL);
  return resp.data.version;
}

function getLocalVersion() {
  if (!$drive.exists(`${APP_DIR}/app.json`)) return "0.0.0";
  return JSON.parse($drive.read(`${APP_DIR}/app.json`).string).version;
}

async function updateApp() {
  $ui.toast("⬇️ Đang tải bản mới...");

  const resp = await $http.download(ZIP_URL);
  const zipPath = "update.zip";

  $drive.write({
    path: zipPath,
    data: resp.data
  });

  // ❗ xoá app cũ
  if ($drive.exists(APP_DIR)) {
    $drive.delete(APP_DIR);
  }

  // ❗ giải nén
  $archiver.unzip({
    file: zipPath,
    dest: ""
  });

  $drive.delete(zipPath);

  $ui.alert("✅ Update xong, mở lại app");
}

async function checkUpdate() {
  const local = getLocalVersion();
  const remote = await getRemoteVersion();

  if (local !== remote) {
    await updateApp();
  }
}

module.exports = { checkUpdate };