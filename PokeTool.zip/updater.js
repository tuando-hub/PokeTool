const VERSION_URL =
  "https://raw.githubusercontent.com/tuando-hub/PokeTool/main/version.json";

function getLocalVersion() {
  const f = $file.read("app.json");
  if (!f) return "0.0.0";
  return JSON.parse(f.string).version || "0.0.0";
}

function compare(a, b) {
  const x = a.split(".").map(Number);
  const y = b.split(".").map(Number);
  for (let i = 0; i < 3; i++) {
    if ((x[i] || 0) > (y[i] || 0)) return 1;
    if ((x[i] || 0) < (y[i] || 0)) return -1;
  }
  return 0;
}

exports.check = async function () {
  try {
    const local = getLocalVersion();
    const remote = (await $http.get(VERSION_URL)).data;

    console.log("Local:", local);
    console.log("Remote:", remote.version);

    if (compare(remote.version, local) <= 0) return;

    $ui.alert({
      title: "🚀 Có bản cập nhật mới",
      message:
        `Version hiện tại: ${local}\n` +
        `Version mới: ${remote.version}\n\n` +
        `${remote.changelog}`,
      actions: [
        {
          title: "Cập nhật",
          handler: () => {
            $app.openURL(
              "https://github.com/tuando-hub/PokeTool/archive/refs/heads/main.zip"
            );
          }
        },
        { title: "Để sau" }
      ]
    });
  } catch (e) {
    console.log("Update failed:", e);
  }
};