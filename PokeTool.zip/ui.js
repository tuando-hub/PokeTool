const Lottery = require("../modes/lottery");
const Create  = require("../modes/create");
const AutoBuy = require("../modes/autobuy");
const ChangeProfile = require("../modes/changeprofile");

const CACHE_KEY = "PokeTool.Cache";

// ================= THEME =================
const THEME = {
  bg: "#020617",
  card: "#0B1220",
  text: "#E5E7EB",
  muted: "#9CA3AF",
  primary: "#6366F1",
  success: "#22C55E",
  secondary: "#1F2937"
};

let CURRENT_MODE = null;

// ================= CACHE =================
function loadCache() {
  return $cache.get(CACHE_KEY) || {};
}

function persist() {
  const state = {
    savedAt: Date.now(),
    mode: CURRENT_MODE,

    imapEmail: $("imapEmail")?.text || "",
    imapPass: $("imapPass")?.text || "",
    buyQty: $("buyQty")?.text || "",
    mailList: $("mailList")?.text || "",
    productIds: $("productIds")?.text || "",

    names: $("names")?.text || "",
    kanas: $("kanas")?.text || "",
    phones: $("phones")?.text || "",
    postcode: $("postcode")?.text || "",
    pref: $("pref")?.text || "",
    address1: $("address1")?.text || "",
    address2: $("address2")?.text || ""
  };

  // lưu vào cache (nhanh)
  $cache.set(CACHE_KEY, state);

  // lưu ra drive (bền) - chỉ 1 file last snapshot
  try {
    $drive.write({
      path: "ui_state_last.json",
      data: $data({ string: JSON.stringify(state, null, 2) })
    });
  } catch (e) {
    console.log("save ui_state_last.json error:", e);
  }
}

// ================= DONE BAR =================
function doneBar() {
  return {
    type: "view",
    props: { height: 44, bgcolor: $color("#0F172A") },
    views: [{
      type: "button",
      props: {
        title: "Done",
        titleColor: $color(THEME.primary),
        font: $font("bold", 16)
      },
      layout: make => {
        make.right.equalTo(-16);
        make.centerY.equalTo();
      },
      events: {
        tapped() {
          const blurFields = [
            "imapEmail",
            "imapPass",
            "mailList",
        
            "productIds",
            "buyQty",
        
            "names",
            "kanas",
            "phones",
        
            "postcode",
            "pref",
            "address1",
            "address2"
          ];
        
          blurFields.forEach(id => {
            const el = $(id);
            if (el) el.blur();
          });
        }
      }
    }]
  };
}

// ================= UI =================
function render() {
  let cache = null;
  
    try {
      if ($drive.exists("ui_state_last.json")) {
        const d = $drive.read("ui_state_last.json");
        if (d?.string) cache = JSON.parse(d.string);
      }
    } catch (e) {}
  
    if (!cache) cache = loadCache();
  
    const pendingText = loadPendingFromDrive();
    if (pendingText !== null) {
      cache.mailList = pendingText;
    }
  
    CURRENT_MODE = cache.mode || null;

  $ui.render({
    props: { title: "PokeAutomation", bgcolor: $color(THEME.bg) },
    views: [

      // ===== TOP BAR =====
      {
        type: "view",
        layout: make => {
          make.top.left.right.equalTo(0);
          make.height.equalTo(64);
        },
        views: [
          {
            type: "button",
            props: {
              id: "btnRun",
              title: "▶ RUN",
              bgcolor: $color(THEME.success),
              titleColor: $color("#fff"),
              radius: 14,
              enabled: false,
              alpha: 0.4
            },
            layout: make => {
              make.left.equalTo(16);
              make.centerY.equalTo();
              make.width.equalTo(140);
              make.height.equalTo(44);
            },
            events: { tapped: onRun }
          },
          {
            type: "button",
            props: {
              title: "RESET",
              bgcolor: $color(THEME.secondary),
              titleColor: $color("#fff"),
              radius: 14
            },
            layout: make => {
              make.right.equalTo(-16);
              make.centerY.equalTo();
              make.width.equalTo(140);
              make.height.equalTo(44);
            },
            events: { tapped: clearAll }
          }
        ]
      },

      // ===== SCROLL =====
      {
        type: "scroll",
        layout: make => {
          make.top.equalTo(64);
          make.left.right.bottom.equalTo(0);
        },
        views: [{
          type: "view",
          props: { id: "content" },
          layout: make => {
            make.top.left.equalTo(0);
            make.width.equalTo($device.info.screen.width);
            make.height.equalTo(2000);
          },
          views: [

            logo(),
            title(),
            modeButton(),
            statusLabel(),

            productCard(cache),
            createCard(cache),
            imapCard(cache),
            mailCard(cache),

            { type: "view", layout: make => make.height.equalTo(120) }
          ]
        }]
      }
    ]
  });

  applyModeUI();
  updateRunState();
}

// ================= COMPONENTS =================
function logo() {
  return {
    type: "image",
    props: { src: "assets/IMG_3233.PNG", radius: 36 },
    layout: make => {
      make.top.equalTo(16);
      make.centerX.equalTo();
      make.size.equalTo($size(72,72));
    }
  };
}

function title() {
  return {
    type: "label",
    props: { text: "PokeAutomation", font: $font("bold", 28), textColor: $color(THEME.text) },
    layout: make => {
      make.top.equalTo(105);
      make.centerX.equalTo();
    }
  };
}

function modeButton() {
  return {
    type: "button",
    props: {
      id: "btnMode",
      title: CURRENT_MODE ? modeTitle(CURRENT_MODE) : "Chọn Mode",
      bgcolor: $color(THEME.primary),
      titleColor: $color("#fff"),
      radius: 18
    },
    layout: make => {
      make.top.equalTo(175);
      make.left.right.inset(20);
      make.height.equalTo(52);
    },
    events: {
      tapped(sender) {
        $ui.menu({
          items: [
            "⬜ Chọn Mode",
            "🎯 Lottery",
            "🛒 Buy",
            "🛠 Create",
            "📝 Change Profile",
            "🔍 Check Result"
          ],
          handler(t) {
            CURRENT_MODE =
              t.includes("Lottery") ? "Lottery" :
              t.includes("Buy")     ? "Buy" :
              t.includes("Create")  ? "Create" :
              t.includes("Change")  ? "ChangeProfile" :
              t.includes("Check")   ? "CheckResult" :
              null;

            sender.title = CURRENT_MODE ? modeTitle(CURRENT_MODE) : "Chọn Mode";
            persist();
            applyModeUI();
            updateRunState();
          }
        });
      }
    }
  };
}

function statusLabel() {
  return {
    type: "label",
    props: { id:"status", font:$font(13), textColor:$color(THEME.muted) },
    layout: make => {
      make.top.equalTo(235);
      make.centerX.equalTo();
    }
  };
}

// ================= CARDS =================
function productCard(cache) {
  return card("productCard", 265, 170, [
    label("Mã Sản Phẩm",16),
    input("productIds","4521329394763,4521329...",44,false,cache.productIds),

    label("SỐ LƯỢNG MUA", 92),
    input("buyQty","1",112,false,cache.buyQty)
  ]);
}

function createCard(cache) {
  return card("createCard", 455, 925, [

    // ===== TITLE =====
    label("THÔNG TIN TẠO ACCOUNT", 16),

    // ===== NAME =====
    label("TÊN (mỗi dòng 1 tên)", 44),
    textarea(
      "names",
      "Yamada Taro\nSuzuki Ichiro",
      64,
      cache.names
    ),

    // ===== KANA =====
    label("TÊN KANA (mỗi dòng 1 tên)", 214),
    textarea(
      "kanas",
      "ヤマダ タロウ\nスズキ イチロウ",
      234,
      cache.kanas
    ),

    // ===== POSTCODE =====
    label("MÃ BƯU ĐIỆN", 384),
    input("postcode", "1440098", 404, false, cache.postcode),

    // ===== PREF =====
    label("TỈNH / THÀNH PHỐ", 452),
    input("pref", "東京都", 472, false, cache.pref),

    // ===== ADDRESS 1 =====
    label("QUẬN / KHU", 520),
    input("address1", "港区芝浦", 540, false, cache.address1),

    // ===== ADDRESS 2 =====
    label("BANCHI / TOÀ NHÀ", 588),
    textarea(
      "address2",
      "1-2-3 101\n1-2-3 101/\n1-2-3 @101",
      608,
      cache.address2
    ),

    // ===== PHONE =====
    label("SỐ ĐIỆN THOẠI (mỗi dòng 1 số)", 758),
    textarea(
      "phones",
      "09012345678\n08099998888",
      778,
      cache.phones
    )
  ]);
}

function imapCard(cache) {
  return card("imapCard", 1400, 190, [
    label("IMAP EMAIL", 16),
    input("imapEmail", "imap@email.com", 44, false, cache.imapEmail),

    label("IMAP PASSWORD", 96),
    input("imapPass", "App Password", 124, true, cache.imapPass)
  ]);
}

function mailCard(cache) {
  return card("mailCard", 1610, 200, [

    // ===== HEADER =====
    {
      type: "view",
      layout: make => {
        make.top.equalTo(12);
        make.left.right.inset(16);
        make.height.equalTo(28);
      },
      views: [

        // Title
        {
          type: "label",
          props: {
            text: "MAIL LIST (mail:pass)",
            font: $font("bold", 12),
            textColor: $color(THEME.muted)
          },
          layout: make => {
            make.left.equalTo(0);
            make.centerY.equalTo();
          }
        },

        // 🔥 CLEAR BUTTON (pill style)
        {
          type: "button",
          props: {
            title: "Xoá",
            font: $font("bold", 11),
            titleColor: $color("#F87171"),
            bgcolor: $color("#1F2937"),
            radius: 10
          },
          layout: make => {
            make.right.equalTo(0);
            make.centerY.equalTo();
            make.width.equalTo(52);
            make.height.equalTo(22);
          },
          events: {
            tapped() {
              if (!$("mailList").text) return;

              $ui.alert({
                title: "Clear mail list?",
                message: "This only clears the list in UI",
                actions: [
                  { title: "Cancel" },
                  {
                    title: "Clear",
                    style: "destructive",
                    handler() {
                      $("mailList").text = "";
                      persist();
                      updateRunState();
                    }
                  }
                ]
              });
            }
          }
        }
      ]
    },

    // ===== TEXTAREA =====
    textarea("mailList", "mail:pass", 50, cache.mailList)
  ]);
}

// ================= MODE LOGIC =================
function applyModeUI() {
  const isLottery = CURRENT_MODE === "Lottery";
  const isCreate  = CURRENT_MODE === "Create";
  const isBuy     = CURRENT_MODE === "Buy";
  const isChange = CURRENT_MODE === "ChangeProfile";
  const hasMode   = !!CURRENT_MODE;

  $("status").text = hasMode ? "" : "Vui lòng chọn mode 👆";

  // Product ID
  setCardEnabled("productCard", isLottery || isBuy);

  // Create card
  setCardEnabled("createCard", isCreate|| isChange);

  // IMAP + MAIL luôn dùng cho mọi mode (trừ Select Mode)
  setCardEnabled("imapCard", hasMode);
  setCardEnabled("mailCard", hasMode);
}

function setCardEnabled(cardId, enabled) {
  const card = $(cardId);
  if (!card) return;

  // 🔥 CHẶN TỪ GỐC
  card.userInteractionEnabled = enabled;
  card.alpha = enabled ? 1 : 0.35;

  card.views.forEach(v => {
    if (v.type === "text") {
      v.editable = enabled;
      v.selectable = enabled;
      v.userInteractionEnabled = enabled;

      if (!enabled) v.blur();
    }
  });
}

// ================= ACTIONS =================
function updateRunState() {
  const needProduct =
    CURRENT_MODE === "Lottery" ||
    CURRENT_MODE === "Buy";

  const ok =
    $("imapEmail")?.text &&
    $("imapPass")?.text &&
    $("mailList")?.text &&
    (!needProduct || $("productIds")?.text);

  $("btnRun").enabled = !!ok;
  $("btnRun").alpha = ok ? 1 : 0.4;
}

function onRun() {
  persist();

  if (CURRENT_MODE === "Lottery") {
  
    Lottery.run({
      imapEmail: $("imapEmail").text,
      imapPass:  $("imapPass").text,
  
      accounts: parseAccounts($("mailList").text),
  
      // 1) array -> lottery đọc ctx.products
      products: $("productIds").text
        .split(",")
        .map(x => x.trim())
        .filter(Boolean),
  
      // 2) string -> lottery đọc ctx.productIds  ← 🔥 THÊM DÒNG NÀY
      productIds: $("productIds").text.trim(),
  
      onProgress(pendingText, meta) {
        const mail = $("mailList");
        if (!mail) return;
  
        mail.blur();
        mail.text = "";
        mail.text = pendingText;
        mail.focus(false);
  
        if (meta?.lastEmail) {
          $("status").text =
            `Lottery ✔ ${meta.lastEmail} | Pending: ${meta.pending}`;
        }
      }
    });
  
    return;
  }
  
    // =========== BUY MODE ==============
    if (CURRENT_MODE === "Buy") {
  
      const qty = Number($("buyQty").text);
  
      // 🔥 VALIDATE SỐ LƯỢNG
      if (!Number.isInteger(qty) || qty <= 0) {
        $ui.toast("❗ Số lượng mua không hợp lệ");
        return;
      }
  
      AutoBuy.run({
        imapEmail: $("imapEmail").text,
        imapPass:  $("imapPass").text,
  
        accounts: parseAccounts($("mailList").text),
  
        products: $("productIds").text
          .split(",")
          .map(x => x.trim())
          .filter(Boolean),
  
        qty, // 👈 truyền thẳng xuống AutoBuy
  
        onProgress(pendingText, meta) {
          const mail = $("mailList");
          if (!mail) return;
  
          mail.blur();
          mail.text = pendingText;
          mail.focus(false);
  
          if (meta?.lastEmail) {
            $("status").text =
              `Buy ✔ ${meta.lastEmail} | Pending: ${meta.pending}`;
          }
        }
      });
  
      return;
    }

  // =========== CREATE MODE =============
  if (CURRENT_MODE === "Create") {

    Create.run({
      imapEmail: $("imapEmail").text,
      imapPass:  $("imapPass").text,
    
      // mail:pass
      accounts: parseAccounts($("mailList").text),
    
      // ===== MULTI =====
      names: $("names").text.split(/\r?\n/).filter(Boolean),
      kanas: $("kanas").text.split(/\r?\n/).filter(Boolean),
      phones: $("phones").text.split(/\r?\n/).filter(Boolean),
    
      // address2 = multi line
      addresses: $("address2").text.split(/\r?\n/).filter(Boolean),
    
      // ===== SINGLE (🔥 BẮT BUỘC) =====
      postcode: $("postcode").text.trim(),
      pref: $("pref").text.trim(),
      address1: $("address1").text.trim(),
    
      onProgress(pendingText, meta) {
        const mail = $("mailList");
        if (!mail) return;
      
        // ===== xoá mail đã chạy =====
        mail.blur();
        mail.text = "";
        mail.text = pendingText;
        mail.focus(false);
      
        // ===== cập nhật status =====
        if (meta?.lastEmail) {
          $("status").text =
            `Create ✔ ${meta.lastEmail} | Pending: ${meta.pending}`;
        }
      
        // ===== 🔥 XOÁ 1 DÒNG DATA CREATE =====
        const shiftLine = id => {
          const el = $(id);
          if (!el || !el.text) return;
      
          const lines = el.text
            .split(/\r?\n/)
            .map(x => x.trim())
            .filter(Boolean);
      
          if (!lines.length) return;
      
          lines.shift();              // ❌ xoá dòng đầu (đã dùng)
          el.text = lines.join("\n");
        };
      
        shiftLine("names");     // tên
        shiftLine("kanas");     // kana
        shiftLine("address2");  // banchi / toà nhà
        //shiftLine("phones");    // phone
      
        // ===== lưu lại cache UI =====
        persist();
        updateRunState();
      }
    });
    return;
  }
  
  // ======== CHANGE PROFILE MODE ===========
      if (CURRENT_MODE === "ChangeProfile") {
      
        ChangeProfile.run({
          imapEmail: $("imapEmail").text,
          imapPass:  $("imapPass").text,
      
          accounts: parseAccounts($("mailList").text),
      
          postcode: $("postcode").text.trim(),
          pref: $("pref").text.trim(),
          city: $("address1").text.trim(),
      
          // address2 = multi-line → mỗi acc dùng 1 dòng
          phones: $("phones").text.split(/\r?\n/).filter(Boolean),
          addresses: $("address2").text
            .split(/\r?\n/)
            .map(x => x.trim())
            .filter(Boolean),
      
          onProgress(pendingText, meta) {
            const mail = $("mailList");
            if (!mail) return;
      
            mail.blur();
            mail.text = pendingText;
            mail.focus(false);
      
            if (meta?.lastEmail) {
              $("status").text =
                `Change ✔ ${meta.lastEmail} | Pending: ${meta.pending}`;
            }
      
            // 🔥 xoá 1 dòng address2 đã dùng
            const shiftLine = id => {
               const el = $(id);
               if (!el || !el.text) return;
                  
               const lines = el.text
                        .split(/\r?\n/)
                        .map(x => x.trim())
                        .filter(Boolean);
                  
               if (!lines.length) return;
                  
                lines.shift();
                el.text = lines.join("\n");
               };
                  
              shiftLine("phones");     // tên
              shiftLine("address2");
      
            persist();
            updateRunState();
          }
        });
      
        return;
      }

  $ui.toast("❗ Please select mode");
}

function clearAll() {
  $ui.alert({
    title: "Xoá tất cả !!",
    message: "Bạn có muốn xoá hết thông tin đã nhập?",
    actions: [
      { title: "Huỷ" },
      {
        title: "Xoá",
        style: "destructive",
        handler() {

          try { Lottery.stop(); } catch(e) {}
          try { Buy.stop(); } catch(e) {}
          try { Create.stop(); } catch(e) {}

          // 2️⃣ Xoá cache UI
          $cache.remove(CACHE_KEY);

          // 3️⃣ Xoá checkpoint files
          ["pending.json", "done.json", "failed.json"].forEach(f => {
            try {
              if ($drive.exists(f)) $drive.delete(f);
            } catch(e){}
          });

          // 4️⃣ Reset UI
          CURRENT_MODE = null;
          [
            "imapEmail","imapPass","mailList",
            "productIds","postcode","pref","address1","address2","names","kanas","phones"
          ].forEach(id => $(id) && ($(id).text = ""));

          $("btnMode").title = "Chọn Mode";
          $("status").text = "Reset completed";

          applyModeUI();
          updateRunState();

          $ui.toast("✅ Reset done");
        }
      }
    ]
  });
}

// ================= HELPERS =================
function card(id, top, height, views) {
  return {
    type:"view",
    props:{ id, bgcolor:$color(THEME.card), radius:16 },
    layout:make=>{
      make.top.equalTo(top);
      make.left.right.inset(20);
      make.height.equalTo(height);
    },
    views
  };
}

function label(text,top) {
  return {
    type:"label",
    props:{ text, font:$font("bold",12), textColor:$color(THEME.muted) },
    layout:make=>{
      make.top.equalTo(top);
      make.left.equalTo(16);
    }
  };
}

function input(id,ph,top,secure,val) {
  return {
    type:"text",
    props:{
      id,text:val||"",placeholder:ph,secure,
      bgcolor:$color("#020617"),
      textColor:$color(THEME.text),
      radius:12,
      accessoryView:doneBar()
    },
    layout:make=>{
      make.top.equalTo(top);
      make.left.right.inset(16);
      make.height.equalTo(40);
    },
    events:{ changed:()=>{ updateRunState(); } }
  };
}

function textarea(id, ph, top, val) {
  return {
    type: "text",
    props: {
      id,
      text: val || "",
      placeholder: ph,
      bgcolor: $color("#020617"),
      textColor: $color(THEME.text),
      radius: 12,
      font: $font(14),
      inset: $insets(10, 8, 10, 8),
      editable: true,
      selectable: true,
      accessoryView: doneBar()
    },
    layout: make => {
      make.top.equalTo(top);
      make.left.right.inset(16);
      make.height.equalTo(130); // ~5 dòng
    },
    events: {

      // 🔥 TAP = DÁN CLIPBOARD
      tapped(sender) {
        const clip = $clipboard.text;
        if (clip && !sender.text) {
          sender.text = clip.trim();
          persist();
          updateRunState();
        }
      },

      changed() {
        updateRunState();
      }
    }
  };
}

function parseAccounts(text) {
  if (!text) return [];

  return text
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean)
    .map(line => {
      const [email, pass] = line.split(":");
      if (!email || !pass) return null;
      return {
        email: email.trim(),
        pass: pass.trim()
      };
    })
    .filter(Boolean);
}

function loadPendingFromDrive() {
  try {
    if (!$drive.exists("pending.json")) return null;
    const d = $drive.read("pending.json");
    if (!d || !d.string) return null;

    const list = JSON.parse(d.string);
    if (!Array.isArray(list)) return null;

    // convert [{email, pass}] -> text
    return list.map(a => `${a.email}:${a.pass}`).join("\n");
  } catch (e) {
    console.log("loadPendingFromDrive error:", e);
    return null;
  }
}

function modeTitle(m) {
  return m==="Lottery" ? "🎯 Lottery" :
         m==="Buy"     ? "🛒 Buy" :
         m==="Create"  ? "🛠 Create" :
         m==="ChangeProfile" ? "📝 Change Profile":
         "🔍 Check Result";
}

module.exports = { render };