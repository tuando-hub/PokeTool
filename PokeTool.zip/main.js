const updater = require("./updater");
updater.check();

const UI = require("./ui");
UI.render();