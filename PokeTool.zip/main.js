const updater = require("./updater");
updater.checkUpdate();

const UI = require("./ui");
UI.render();