
//=============================================

// ================= URL =================
const LOGIN_URL   = "https://www.pokemoncenter-online.com/login/";
const LANDING_URL = "https://www.pokemoncenter-online.com/lottery/landing-page.html";

// ================= CHECKPOINT FILES =================
const PENDING_FILE = "pending.json";
const DONE_FILE    = "done.json";
const FAILED_FILE  = "failed.json";

// ================= TIMING =================
const DELAY_STEP         = 1500;
const POLL_OTP_INTERVAL  = 2000;
const POLL_OTP_TIMEOUT   = 300000; // 5 phút
const PAGE_TIMEOUT       = 20000;

// ================= RUNTIME =================
let IMAP_EMAIL = "";
let IMAP_PASS  = "";
let STOP_FLAG  = false;

// ✅ runtime products (từ UI)
let PRODUCTS_RUNTIME = null;

// ================= PRODUCTS (giữ như flow cũ) =================
// Muốn nhiều sản phẩm thì thêm object vào mảng này.
const PRODUCTS = [
  {
    label: "MEGA ハイクラスパック MEGAドリームex BOX",
    radio: 'input[name="L0000000043radio"]',
    checkbox: '#L0000000043',
    button: '.mailForm.L0000000043 a.popup-modal'
  }
];

// ================= UTIL =================
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

function readJSON(path, defVal) {
  try {
    if (!$drive.exists(path)) return defVal;
    const d = $drive.read(path);
    if (!d || !d.string) return defVal;
    return JSON.parse(d.string);
  } catch (e) {
    console.log("readJSON error:", path, e);
    return defVal;
  }
}

function writeJSON(path, data) {
  try {
    $drive.write({
      path,
      data: $data({ string: JSON.stringify(data, null, 2) })
    });
  } catch (e) {
    console.log("writeJSON error:", path, e);
  }
}

function toText(list) {
  return (list || []).map(a => `${a.email}:${a.pass}`).join("\n");
}

function callProgress(ctx, pending, meta) {
  try {
    if (ctx && typeof ctx.onProgress === "function") {
      ctx.onProgress(toText(pending), meta || {});
    }
  } catch (e) {
    console.log("onProgress error:", e);
  }
}

// ================= STOP =================
function stop() {
  STOP_FLAG = true;
  $ui.toast("⛔ Stop requested");
}

// =======================================================
// ✅ PRODUCTS from UI
// - ctx.products: ["L0000000043","L0000000044"]
// - ctx.productIds: "L0000000043,L0000000044"
// - fallback: const PRODUCTS
// =======================================================
function buildProductsFromCtx(ctx) {
  try {
    let ids = [];

    if (ctx && Array.isArray(ctx.products)) {
      ids = ctx.products;
    } else if (ctx && typeof ctx.productIds === "string") {
      ids = ctx.productIds.split(",").map(s => s.trim()).filter(Boolean);
    }

    ids = (ids || []).map(s => (s || "").trim()).filter(Boolean);

    if (!ids.length) return null;

    // Map đúng theo selector pattern cũ:
    // radio: input[name="${ID}radio"]
    // checkbox: #${ID}
    // button: .mailForm.${ID} a.popup-modal
    return ids.map(id => ({
      label: id,
      radio: `input[name="${id}radio"]`,
      checkbox: `#${id}`,
      button: `.mailForm.${id} a.popup-modal`
    }));
  } catch (e) {
    console.log("buildProductsFromCtx error:", e);
    return null;
  }
}

// =======================================================
// PAGE READY (giữ kiểu cũ + thêm fallback)
// =======================================================
async function waitPageReady(wv, timeout = PAGE_TIMEOUT) {
  const start = Date.now();
  wv._pageReady = false;

  while (!wv._pageReady) {
    await delay(50);
    if (STOP_FLAG) return false;
    if (Date.now() - start > timeout) {
      // fallback: thử đọc document.readyState
      try {
        const rs = await wv.eval({ script: "document.readyState" });
        if (rs === "interactive" || rs === "complete") return true;
      } catch (e) {}
      console.log("⏱ waitPageReady timeout");
      return false;
    }
  }
  return true;
}

// =======================================================
// OTP via PYTO (GIỮ LOGIC CŨ: TO + UNSEEN intersection)
// =======================================================
async function callPytoGetOtp(targetMail) {
  let imapServer = "imap.mail.me.com";
  const lower = (IMAP_EMAIL || "").toLowerCase();

  if (lower.endsWith("@gmail.com")) imapServer = "imap.gmail.com";
  else if (lower.endsWith("@icloud.com") || lower.endsWith("@me.com")) imapServer = "imap.mail.me.com";
  else imapServer = "imap.mail.me.com";

  const pythonCode = `
import imaplib, email, re, time
import pasteboard, webbrowser

EMAIL = "${IMAP_EMAIL}"
PASSWORD = "${IMAP_PASS}"
IMAP_SERVER = "${imapServer}"
FOLDER = "INBOX"
MAILACC = "${targetMail}"

def get_latest_code(delete_after=True):
    imap = None
    try:
        imap = imaplib.IMAP4_SSL(IMAP_SERVER, 993)
        imap.login(EMAIL, PASSWORD)
        imap.select(FOLDER)

        # Mail đúng người nhận
        status, to_ids = imap.search(None, f'TO "{MAILACC}"')
        if status != "OK":
            return None
        to_list = set(to_ids[0].split())
        if not to_list:
            return None

        # Mail chưa đọc
        status, unseen_ids = imap.search(None, "UNSEEN")
        if status != "OK":
            return None
        unseen_list = set(unseen_ids[0].split())

        # Giao 2 tập
        target_ids = sorted(list(to_list.intersection(unseen_list)))
        if not target_ids:
            return None

        latest_id = target_ids[-1]

        status, msg_data = imap.fetch(latest_id, "BODY[]")
        if status != "OK" or not msg_data:
            return None

        raw_email = msg_data[0][1]
        msg = email.message_from_bytes(raw_email)

        # Parse body
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                ctype = part.get_content_type()
                payload = part.get_payload(decode=True)
                if not payload:
                    continue
                if ctype == "text/plain":
                    body += payload.decode("utf-8", errors="ignore")
                elif ctype == "text/html":
                    html = payload.decode("utf-8", errors="ignore")
                    text = re.sub(r"<[^>]+>", " ", html)
                    body += text
        else:
            payload = msg.get_payload(decode=True)
            if payload:
                body = payload.decode("utf-8", errors="ignore")

        # Regex OTP
        m = re.search(r"【パスコード】\\s*(\\d{6})", body) or re.search(r"\\b(\\d{6})\\b", body)
        if not m:
            return None

        otp = m.group(1)

        if delete_after:
            imap.store(latest_id, "+FLAGS", "\\\\Seen")
            imap.store(latest_id, "+FLAGS", "\\\\Deleted")
            imap.expunge()

        return otp

    except:
        return None

    finally:
        if imap:
            try: imap.close()
            except: pass
            try: imap.logout()
            except: pass

def wait_for_otp(timeout=300, interval=5):
    start = time.time()
    while time.time() - start < timeout:
        code = get_latest_code()
        if code:
            return code
        time.sleep(interval)
    return None

otp = wait_for_otp()
if otp:
    pasteboard.set_string(otp)
    print(otp, end="")
else:
    pasteboard.set_string("")
    print("No OTP received", end="")

webbrowser.open("jsbox://")
`;

  $app.openURL("pyto://x-callback/?code=" + encodeURIComponent(pythonCode));
}

async function waitClipboardForOtp(timeout = POLL_OTP_TIMEOUT, interval = POLL_OTP_INTERVAL) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    if (STOP_FLAG) return null;
    const clip = $clipboard.text || "";
    if (/^\d{6}$/.test(clip)) return clip;
    await delay(interval);
  }
  return null;
}

async function getOtpWithPyto(targetMail) {
  $clipboard.text = "";
  await delay(1500);
  await callPytoGetOtp(targetMail);
  return await waitClipboardForOtp();
}

// =======================================================
// WEBVIEW (giữ kiểu cũ: didFinish + didReceiveResponse)
// =======================================================
async function createWebView(title) {
  return new Promise(resolve => {
    $ui.push({
      props: { title },
      views: [{
        type: "web",
        props: { id: "wv", url: "about:blank" },
        layout: $layout.fill,
        events: {
          didFinish: sender => {
            sender._pageReady = true;
          },
          didReceiveResponse: (sender, resp) => {
            try {
              const url = resp.URL || "";
              if (
                url.includes("/auth/login-status") ||
                url.includes("/cart/get") ||
                url.includes("/order/") ||
                url.includes("/mypage") ||
                url.includes("/lottery")
              ) {
                sender._pageReady = true;
              }
            } catch (e) {}
          }
        }
      }],
      events: { appeared: () => resolve($("wv")) }
    });
  });
}

async function clearSessionInWebView(wv) {
  try {
    wv.url = "https://www.pokemoncenter-online.com/logout/";
    await delay(1000);
    await wv.eval({
      script: `
        try{
          document.cookie.split(";").forEach(function(c){
            document.cookie = c.replace(/=.*/, "=;expires=" + new Date(0).toUTCString() + ";path=/");
          });
          localStorage.clear();
          sessionStorage.clear();
        }catch(e){}
        true;
      `
    });
  } catch (e) {
    console.log("clearSession error:", e);
  }
}

async function showNotify(wv, message, duration = 4000) {
  if (!wv) return;
  try {
    await wv.eval({
      script: `
        (function(){
          let existing = document.getElementById("jsbox-notify");
          if(existing) existing.remove();
          let div = document.createElement("div");
          div.id = "jsbox-notify";
          div.innerText = ${JSON.stringify(message)};
          div.style.cssText = "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.8);color:#fff;padding:12px 20px;border-radius:8px;font-size:16px;z-index:99999;box-shadow:0 4px 12px rgba(0,0,0,0.3);transition:opacity 0.3s;width:450px;max-width:90vw;text-align:center;";
          div.style.opacity = "0";
          document.body.appendChild(div);
          setTimeout(()=>{ div.style.opacity="1"; }, 50);
          setTimeout(()=>{ div.style.opacity="0"; setTimeout(()=>{ div.remove(); }, 400); }, ${duration});
        })();
      `
    });
  } catch (e) {}
}

async function acceptTermsIfNeeded(wv) {
  // giữ đúng logic cũ
  try {
    const res = await wv.eval({
      script: `
        (function(){
          const chk = document.querySelector('#terms');
          const btn = document.querySelector('#terms_button');
          if (chk && btn) {
            chk.checked = true;
            chk.dispatchEvent(new Event('change', {bubbles:true}));
            btn.disabled = false;
            btn.classList.remove('disabled');
            btn.click();
            return "ACCEPTED";
          }
          return "NO_TERMS";
        })();
      `
    });
    return res;
  } catch (e) {
    return "ERR";
  }
}

// =======================================================
// PER ACCOUNT FLOW (GIỮ ĐÚNG FLOW CŨ)
// =======================================================
async function processAccount(acc, index, total) {
  const email = acc.email;
  const pass  = acc.pass;

  console.log("\n=== Account " + (index + 1) + "/" + total + ": " + email + " ===");

  const wv = await createWebView((index + 1) + "/" + total);
  await clearSessionInWebView(wv);
  await delay(500);

  if (STOP_FLAG) { try { wv.remove(); } catch(e) {} return { ok:false, reason:"STOP" }; }

  // LOGIN
  wv.url = LOGIN_URL + "?t=" + Date.now();
  await waitPageReady(wv);
  await showNotify(wv, "(" + (index + 1) + "/" + total + ") Login Mail:\n" + email, 4000);

  await wv.eval({ script: `var el=document.querySelector('#login-form-email'); if(el) el.value=${JSON.stringify(email)};` });
  await delay(DELAY_STEP);
  await wv.eval({ script: `var el=document.querySelector('#current-password'); if(el) el.value=${JSON.stringify(pass)};` });
  await delay(DELAY_STEP);
  await wv.eval({ script: `var btn=document.querySelector('#form1Button'); if(btn) btn.click();` });
  console.log("➡️ Login submitted");
  await waitPageReady(wv);
  await delay(3000);

  if (STOP_FLAG) { try { wv.remove(); } catch(e) {} return { ok:false, reason:"STOP" }; }

  // OTP
  await showNotify(wv, "(" + (index + 1) + "/" + total + ") ⏳ Waiting for OTP...", 4000);
  const otp = await getOtpWithPyto(email);
  if (!otp) {
    await showNotify(wv, "❌ OTP timeout", 4000);
    try { wv.remove(); } catch(e) {}
    return { ok:false, reason:"OTP_TIMEOUT" };
  }

  await wv.eval({ script: `var el=document.querySelector('#authCode'); if(el) el.value=${JSON.stringify(otp)};` });
  await delay(DELAY_STEP);

  await wv.eval({ script: `(document.querySelector('#authBtn')||document.querySelector('#certify')||document.querySelector('button[type=submit]'))?.click();` });
  await waitPageReady(wv);

  if (STOP_FLAG) { try { wv.remove(); } catch(e) {} return { ok:false, reason:"STOP" }; }

  // TERMS (giữ flow cũ)
  await showNotify(wv, "(" + (index + 1) + "/" + total + ") ✅ Check terms...", 3500);
  await acceptTermsIfNeeded(wv);
  await delay(2500);

  // LANDING
  console.log("➡️ Go to landing page...");
  await showNotify(wv, "(" + (index + 1) + "/" + total + ") ➡️ Go to landing page...", 3500);
  wv.url = LANDING_URL;
  await delay(3000);

  // goLottery
  await wv.eval({ script: `var btn=document.querySelector('.goLotteryBtn'); if(btn) btn.click();` });
  await waitPageReady(wv);
  await delay(3500);

  if (STOP_FLAG) { try { wv.remove(); } catch(e) {} return { ok:false, reason:"STOP" }; }

  // ✅ APPLY PRODUCTS (lấy từ UI nếu có, fallback PRODUCTS)
  const list = Array.isArray(PRODUCTS_RUNTIME) && PRODUCTS_RUNTIME.length ? PRODUCTS_RUNTIME : PRODUCTS;

  for (let p of list) {
    console.log("🎯 Starting 抽選応募:", p.label);
    await showNotify(wv, "(" + (index + 1) + "/" + total + ") 🎯 " + p.label, 4000);

    await wv.eval({
      script: `
        (function(){
          const sel = ${JSON.stringify(p.radio)};
          const r = document.querySelector(sel);
          if (!r) return "NO_RADIO";
    
          r.checked = true;
          r.dispatchEvent(new Event("input", { bubbles: true }));
          r.dispatchEvent(new Event("change", { bubbles: true }));
          r.click(); // 🔥 BẮT BUỘC
    
          return "OK";
        })();
      `
    });
    await delay(DELAY_STEP);
    
    await wv.eval({ script: `var c=document.querySelector(${JSON.stringify(p.checkbox)}); if(c) c.checked=true;` });
    await delay(DELAY_STEP);
    
    await wv.eval({ script: `var b=document.querySelector(${JSON.stringify(p.button)}); if(b) b.click();` });
    await delay(DELAY_STEP);
    
    await wv.eval({ script: `var b=document.querySelector("#applyBtn"); if(b) b.click();` });
    console.log("🎉 応募 done:", p.label);
    await showNotify(wv, "(" + (index + 1) + "/" + total + ") 🎉 応募完了: " + p.label, 4000);

    await delay(6500);
    if (STOP_FLAG) break;
  }

  if (STOP_FLAG) { try { wv.remove(); } catch(e) {} return { ok:false, reason:"STOP" }; }

  // Back to MyPage (giữ flow cũ)
  await delay(1000);
  await wv.eval({ script: `var link=document.querySelector('.comBackLink a'); if(link) link.click();` });
  await waitPageReady(wv);

  // Logout (giữ flow cũ)
  await showNotify(wv, "(" + (index + 1) + "/" + total + ") 🚪 Logged out!", 3500);
  await wv.eval({ script: `var btn=document.querySelector('a.logout'); if(btn) btn.click();` });
  console.log("🚪 Logged out");
  await waitPageReady(wv);

  await clearSessionInWebView(wv);

  // đóng webview
  try { wv.remove(); } catch(e) {}
  $ui.pop();
  await delay(1000);

  // Reset IP (giữ flow cũ)
  $app.openURL("shortcuts://run-shortcut?name=" + encodeURIComponent("Reset IP"));
  await delay(6000);

  return { ok:true, reason:"OK" };
}

// =======================================================
// CHECKPOINT INIT / RESUME
// =======================================================
function ensureCheckpointInitialized(inputAccounts) {
  // Nếu pending.json chưa có -> init mới.
  // Nếu pending.json đã có (resume) -> giữ nguyên.
  if ($drive.exists(PENDING_FILE)) return;

  writeJSON(PENDING_FILE, inputAccounts || []);
  writeJSON(DONE_FILE, []);
  writeJSON(FAILED_FILE, []);
}

// =======================================================
// ENTRY
// =======================================================
async function run(ctx) {
  STOP_FLAG = false;

  if (!ctx) { $ui.alert("ctx missing"); return; }
  IMAP_EMAIL = (ctx.imapEmail || "").trim();
  IMAP_PASS  = (ctx.imapPass  || "").trim();

  if (!IMAP_EMAIL || !IMAP_PASS) {
    $ui.alert("Missing IMAP email/pass");
    return;
  }

  // ✅ set products runtime từ UI (không có thì fallback PRODUCTS)
  PRODUCTS_RUNTIME = buildProductsFromCtx(ctx);
  if (Array.isArray(PRODUCTS_RUNTIME) && PRODUCTS_RUNTIME.length) {
    console.log("✅ PRODUCTS from UI:", PRODUCTS_RUNTIME.map(p => p.label).join(", "));
  } else {
    console.log("ℹ️ PRODUCTS fallback default:", (PRODUCTS || []).map(p => p.label).join(", "));
  }

      // ✅ MỖI LẦN RUN = RESET CHECKPOINT THEO UI (KHÔNG RESUME)
      let pending = Array.isArray(ctx.accounts) ? ctx.accounts.slice() : [];
      let done    = [];
      let failed  = [];
    
      writeJSON(PENDING_FILE, pending);
      writeJSON(DONE_FILE, done);
      writeJSON(FAILED_FILE, failed);
    
      // ✅ verify + flush (đảm bảo đã lưu xong mới chạy)
      await delay(200);
      const verify = readJSON(PENDING_FILE, null);
      if (!Array.isArray(verify)) {
        $ui.alert("❌ pending.json save failed");
        return;
      }
      pending = verify; // dùng đúng cái vừa lưu
    
      console.log("✅ pending.json saved:", pending.length);

  // Nếu UI vừa nhập list mới mà pending đang trống -> cho phép “start new”
  // (trường hợp đã chạy xong hết, pending = [])
  if (pending.length === 0 && Array.isArray(ctx.accounts) && ctx.accounts.length > 0) {
    // start new batch
    pending = ctx.accounts.slice();
    done = [];
    failed = [];
    writeJSON(PENDING_FILE, pending);
    writeJSON(DONE_FILE, done);
    writeJSON(FAILED_FILE, failed);
  }

  // đẩy pending lên UI ngay từ đầu (để UI = đúng thứ sẽ chạy)
  callProgress(ctx, pending, { stage: "INIT", pending: pending.length, done: done.length, failed: failed.length });

  console.log("🎯 LOTTERY START");
  console.log("IMAP:", IMAP_EMAIL);
  console.log("PENDING:", pending.length);

  const totalStart = pending.length;

  let i = 0;
  while (pending.length > 0) {
    if (STOP_FLAG) {
      console.log("⛔ STOPPED by user");
      break;
    }

    const acc = pending[0];

    let result = { ok:false, reason:"ERR" };
    try {
      result = await processAccount(acc, i, totalStart);
    } catch (e) {
      console.log("❌ Exception:", e);
      result = { ok:false, reason:"EXCEPTION" };
    }

    // remove from pending in ALL cases (đúng kiểu checkpoint)
    pending.shift();

    if (result.ok) done.push({ email: acc.email, at: Date.now() });
    else failed.push({ email: acc.email, pass: acc.pass, reason: result.reason, at: Date.now() });

    // save checkpoint mỗi acc
    writeJSON(PENDING_FILE, pending);
    writeJSON(DONE_FILE, done);
    writeJSON(FAILED_FILE, failed);

    // update UI realtime: xoá acc đã xử lý khỏi textarea
    callProgress(ctx, pending, {
      stage: "PROGRESS",
      currentIndex: i,
      totalStart,
      lastEmail: acc.email,
      lastOk: result.ok,
      lastReason: result.reason,
      pending: pending.length,
      done: done.length,
      failed: failed.length
    });

    i++;
    await delay(1500);
  }

  if (STOP_FLAG) {
    $ui.alert("⛔ Stopped. You can press RUN later to resume (pending.json).");
    return;
  }

  console.log("🎉 LOTTERY FINISHED");
  $ui.alert("🎉 Lottery finished (pending empty).");
}

// =======================================================
module.exports = {
  run,
  stop
};